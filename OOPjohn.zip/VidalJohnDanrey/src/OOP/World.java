
package OOP;
public class World {
    public static void main(String[] args) {
        Character CH = new Character();
        CH.info();
        CH.newLife();
                
        
        
        
    }
    
}
